use vsc to run code simple
